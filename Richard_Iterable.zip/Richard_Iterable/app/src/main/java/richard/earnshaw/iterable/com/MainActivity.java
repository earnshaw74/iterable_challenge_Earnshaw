package richard.earnshaw.iterable.com;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import com.iterable.iterableapi.IterableApi;
import com.iterable.iterableapi.IterableConfig;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        IterableConfig config = new IterableConfig.Builder().build();
      IterableApi.initialize(this.getApplicationContext(), "349dcc9373c74c6699c5d1204a271695", config);
        IterableApi.getInstance().setEmail("richard_earnshaw@hotmail.com");

        final IterableApi api = IterableApi.getInstance();
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "emailupdated", Snackbar.LENGTH_LONG)
                        .setAction("action", awesomeOnClickListener).show();
            }
        });
        Button two = findViewById(R.id.Event);
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "eventsent", Snackbar.LENGTH_LONG)
                        .setAction("action", secondOnClickListener).show();
            }
        });
    }

    private View.OnClickListener secondOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                sendTestEvent();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private View.OnClickListener awesomeOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                updateEmail();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    public void sendTestEvent() throws JSONException {
        // Inflate the menu; this adds items to the action bar if it is present.

        IterableApi.getInstance().track("mobileSATestEvent", (new JSONObject("{\"platform\":\"Android\",\"isTestEvent\":true , \"url\":\"https://iterable.com/sa-test/richard\" \"secret_code_key\":\"Code_123\"}")));
    }

    public void updateEmail() throws JSONException {
        // Inflate the menu; this adds items to the action bar if it is present.
        IterableApi.getInstance().updateUser(new JSONObject("{\"firstName\":\"richard\",\"isRegisteredUser\":true , \"SA_User_Test_Key\":\"completed\"}"));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }
}